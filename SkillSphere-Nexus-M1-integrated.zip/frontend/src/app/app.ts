import { Component, OnInit } from '@angular/core';

interface FieldDef { name: string; label: string; type?: string; required?: boolean; placeholder?: string; }
interface ModuleDef { name: string; icon: string; slug: string; fields: FieldDef[]; description: string; }

@Component({ selector: 'app-root', standalone: true, imports: [], templateUrl: './app.html', styleUrl: './app.css' })
export class App implements OnInit {
  readonly api = 'http://localhost:8080/api';
  activeModule = 'Dashboard';
  employees: any[] = [];
  skills: any[] = [];
  assessments: any[] = [];
  certifications: any[] = [];
  records: any[] = [];
  message = '';
  loading = false;
  apiError = '';

  modules: ModuleDef[] = [
    { name: 'Dashboard', icon: '◫', slug: 'dashboard', description: 'Live platform overview', fields: [] },
    { name: 'Employee Management', icon: '♙', slug: 'employees', description: 'Create and manage employee profiles.', fields: [
      {name:'name',label:'Full name',required:true,placeholder:'Enter full name'}, {name:'email',label:'Email address',type:'email',required:true,placeholder:'name@company.com'}, {name:'department',label:'Department',required:true,placeholder:'Engineering'}, {name:'jobRole',label:'Job role',placeholder:'Software Developer'}, {name:'primarySkill',label:'Primary skill',placeholder:'Java'}, {name:'experienceYears',label:'Experience (years)',type:'number',placeholder:'0'} ] },
    { name: 'Skill Management', icon: '✦', slug: 'skills', description: 'Maintain the skill catalogue and proficiency details.', fields: [
      {name:'name',label:'Skill name',required:true,placeholder:'Java'}, {name:'category',label:'Category',required:true,placeholder:'Programming'}, {name:'description',label:'Description',type:'textarea',placeholder:'Describe the skill'} ] },
    { name: 'Assessments', icon: '✓', slug: 'assessments', description: 'Record an employee assessment score. A certificate is generated automatically for a score of 70 or above.', fields: [
      {name:'employeeId',label:'Employee ID',type:'number',required:true,placeholder:'ID from employee directory'}, {name:'skillId',label:'Skill ID (optional)',type:'number',placeholder:'ID from skills catalogue'}, {name:'score',label:'Score (0–100)',type:'number',required:true,placeholder:'85'}, {name:'assessor',label:'Assessor',required:true,placeholder:'HR / Trainer'} ] },
    { name: 'Certifications', icon: '▤', slug: 'certifications', description: 'Certificates are automatically recorded when an assessment score is at least 70.', fields: [] },
    { name: 'Career Development', icon: '◎', slug: 'career-development', description: 'Track career goals, target roles and development actions.', fields: [
      {name:'employeeName',label:'Employee name or ID',required:true,placeholder:'Employee name / ID'}, {name:'careerGoal',label:'Career goal',required:true,placeholder:'Become a Senior Developer'}, {name:'targetRole',label:'Target role',required:true,placeholder:'Senior Developer'}, {name:'targetDate',label:'Target date',type:'date'}, {name:'requiredSkills',label:'Required skills',type:'textarea',placeholder:'Spring Boot, Angular'}, {name:'progress',label:'Progress (%)',type:'number',placeholder:'0'}, {name:'managerComments',label:'Manager comments',type:'textarea'} ] },
    { name: 'Training Administration', icon: '▣', slug: 'training-administration', description: 'Create and track training courses and sessions.', fields: [
      {name:'courseTitle',label:'Course title',required:true,placeholder:'Spring Boot Fundamentals'}, {name:'description',label:'Description',type:'textarea'}, {name:'instructor',label:'Instructor',required:true,placeholder:'Trainer name'}, {name:'trainingMode',label:'Training mode',required:true,placeholder:'Online / Classroom'}, {name:'startDate',label:'Start date',type:'date'}, {name:'endDate',label:'End date',type:'date'}, {name:'capacity',label:'Capacity',type:'number'}, {name:'status',label:'Status',placeholder:'Planned'} ] },
    { name: 'Competency Framework', icon: '◈', slug: 'competency-framework', description: 'Define required competencies and evaluate skill gaps.', fields: [
      {name:'frameworkName',label:'Framework name',required:true,placeholder:'Java Developer Framework'}, {name:'jobRole',label:'Job role',required:true,placeholder:'Java Developer'}, {name:'competency',label:'Competency',required:true,placeholder:'Problem solving'}, {name:'requiredLevel',label:'Required level',required:true,placeholder:'Advanced'}, {name:'actualLevel',label:'Actual level',placeholder:'Intermediate'}, {name:'reviewer',label:'Reviewer'}, {name:'reviewDate',label:'Review date',type:'date'} ] },
    { name: 'Internal Job Opportunities', icon: '⌕', slug: 'internal-job-opportunities', description: 'Publish internal vacancies and track applications.', fields: [
      {name:'jobTitle',label:'Job title',required:true,placeholder:'Backend Developer'}, {name:'department',label:'Department',required:true,placeholder:'Engineering'}, {name:'location',label:'Location',placeholder:'Chennai'}, {name:'description',label:'Job description',type:'textarea',required:true}, {name:'requiredSkills',label:'Required skills',type:'textarea'}, {name:'experienceRequired',label:'Experience required',type:'number'}, {name:'closingDate',label:'Closing date',type:'date'}, {name:'status',label:'Status',placeholder:'Open'} ] },
    { name: 'Learning Analytics', icon: '▥', slug: 'learning-analytics', description: 'Save report requests and view the live totals above.', fields: [
      {name:'reportName',label:'Report name',required:true,placeholder:'Quarterly learning summary'}, {name:'department',label:'Department filter',placeholder:'All departments'}, {name:'startDate',label:'Start date',type:'date'}, {name:'endDate',label:'End date',type:'date'}, {name:'notes',label:'Notes',type:'textarea'} ] },
    { name: 'Workforce Development', icon: '♧', slug: 'workforce-development', description: 'Plan department-level skill development initiatives.', fields: [
      {name:'initiativeName',label:'Initiative name',required:true,placeholder:'Cloud upskilling'}, {name:'department',label:'Department',required:true,placeholder:'Engineering'}, {name:'targetSkill',label:'Target skill',required:true,placeholder:'Cloud computing'}, {name:'identifiedGap',label:'Identified skill gap',type:'textarea'}, {name:'plannedTraining',label:'Planned training',placeholder:'AWS fundamentals'}, {name:'budget',label:'Budget',type:'number'}, {name:'startDate',label:'Start date',type:'date'}, {name:'endDate',label:'End date',type:'date'}, {name:'status',label:'Status',placeholder:'Planned'} ] },
    { name: 'Enterprise Talent Management', icon: '◇', slug: 'enterprise-talent-management', description: 'Track talent strengths, readiness and succession plans.', fields: [
      {name:'employeeName',label:'Employee name or ID',required:true,placeholder:'Employee name / ID'}, {name:'strengths',label:'Strengths',type:'textarea',required:true}, {name:'performanceRating',label:'Performance rating (1–5)',type:'number'}, {name:'readiness',label:'Next-role readiness',placeholder:'Ready in 6 months'}, {name:'successionRole',label:'Succession role',placeholder:'Team Lead'}, {name:'reviewDate',label:'Review date',type:'date'}, {name:'managerComments',label:'Manager comments',type:'textarea'} ] }
  ];

  ngOnInit(): void { this.refreshCore(); }
  get activeDef(): ModuleDef { return this.modules.find(m => m.name === this.activeModule) ?? this.modules[0]; }
  get isGenericModule(): boolean { return !['Dashboard','Employee Management','Skill Management','Assessments','Certifications'].includes(this.activeModule); }

  async request(path: string, options: RequestInit = {}): Promise<any> {
    const response = await fetch(this.api + path, { ...options, headers: { 'Content-Type':'application/json', ...(options.headers || {}) } });
    if (!response.ok) { const body = await response.text(); throw new Error(body || `Request failed (${response.status})`); }
    if (response.status === 204) return null;
    const text = await response.text(); return text ? JSON.parse(text) : null;
  }
  async refreshCore(): Promise<void> {
    try {
      const results = await Promise.all([this.request('/employees'), this.request('/skills'), this.request('/assessments'), this.request('/certifications')]);
      [this.employees, this.skills, this.assessments, this.certifications] = results;
      this.apiError = '';
    } catch (e) { this.apiError = e instanceof Error ? e.message : 'Backend is unavailable. Start Spring Boot on port 8080.'; }
    if (this.isGenericModule) await this.loadRecords();
  }
  async selectModule(name: string): Promise<void> {
    this.activeModule = name; this.message = ''; this.apiError = '';
    if (name === 'Dashboard' || ['Employee Management','Skill Management','Assessments','Certifications'].includes(name)) await this.refreshCore();
    if (this.isGenericModule) await this.loadRecords();
  }
  async loadRecords(): Promise<void> {
    try { this.records = await this.request('/module-records/' + this.activeDef.slug); }
    catch (e) { this.records = []; this.apiError = e instanceof Error ? e.message : 'Could not load module records.'; }
  }
  async submitForm(event: Event, form: HTMLFormElement): Promise<void> {
    event.preventDefault(); this.message = ''; this.loading = true;
    const raw: Record<string, any> = Object.fromEntries(new FormData(form).entries());
    try {
      if (this.activeModule === 'Employee Management') {
        raw['experienceYears'] = Number(raw['experienceYears'] || 0);
        await this.request('/employees', { method:'POST', body:JSON.stringify(raw) });
        this.message = 'Employee saved to the database.';
      } else if (this.activeModule === 'Skill Management') {
        await this.request('/skills', { method:'POST', body:JSON.stringify(raw) });
        this.message = 'Skill saved to the database.';
      } else if (this.activeModule === 'Assessments') {
        raw['employeeId'] = Number(raw['employeeId']);
        raw['skillId'] = raw['skillId'] ? Number(raw['skillId']) : null;
        raw['score'] = Number(raw['score']);
        const result = await this.request('/assessments', { method:'POST', body:JSON.stringify(raw) });
        this.message = result.passed ? 'Assessment saved. Employee passed and a certificate was generated automatically.' : 'Assessment saved. Score is below 70, so no certificate was generated.';
      } else if (this.isGenericModule) {
        await this.request('/module-records/' + this.activeDef.slug, { method:'POST', body:JSON.stringify(raw) });
        this.message = 'Record saved successfully.';
      }
      form.reset(); await this.refreshCore(); if (this.isGenericModule) await this.loadRecords();
    } catch (e) { this.message = e instanceof Error ? e.message : 'Save failed. Check backend and database connection.'; }
    finally { this.loading = false; }
  }
  async deleteRecord(id: number): Promise<void> {
    if (!confirm('Delete this record?')) return;
    try { await this.request('/module-records/' + this.activeDef.slug + '/' + id, {method:'DELETE'}); this.message='Record deleted.'; await this.loadRecords(); }
    catch(e) { this.message = e instanceof Error ? e.message : 'Delete failed.'; }
  }
  async deleteEmployee(id: number): Promise<void> {
    if (!confirm('Delete this employee? Linked records may prevent deletion.')) return;
    try { await this.request('/employees/' + id, {method:'DELETE'}); await this.refreshCore(); this.message='Employee deleted.'; }
    catch(e) { this.message=e instanceof Error ? e.message : 'Delete failed.'; }
  }
  async deleteSkill(id: number): Promise<void> {
    if (!confirm('Delete this skill? It may be linked to other records.')) return;
    try { await this.request('/skills/' + id, {method:'DELETE'}); await this.refreshCore(); this.message='Skill deleted.'; }
    catch(e) { this.message=e instanceof Error ? e.message : 'Delete failed.'; }
  }
}
