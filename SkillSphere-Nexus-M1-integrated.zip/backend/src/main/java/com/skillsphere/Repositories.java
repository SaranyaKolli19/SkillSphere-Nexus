package com.skillsphere;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.*;

interface EmployeeRepository extends JpaRepository<Employee, Long> {}
interface SkillRepository extends JpaRepository<Skill, Long> {}
interface EmployeeSkillRepository extends JpaRepository<EmployeeSkill, Long> {
    List<EmployeeSkill> findByEmployeeId(Long employeeId);
}
interface AssessmentRepository extends JpaRepository<Assessment, Long> {}
interface CertificationRepository extends JpaRepository<Certification, Long> {
    List<Certification> findByEmployeeId(Long employeeId);
}

interface ModuleRecordRepository extends JpaRepository<ModuleRecord, Long> { java.util.List<ModuleRecord> findByModuleKeyOrderByCreatedAtDesc(String moduleKey); }
