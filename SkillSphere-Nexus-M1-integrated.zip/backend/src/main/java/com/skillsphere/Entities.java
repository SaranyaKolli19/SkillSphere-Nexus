package com.skillsphere;

import jakarta.persistence.*;
import jakarta.validation.constraints.*;
import java.time.LocalDate;

@Entity
@Table(name = "employees")
class Employee {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @NotBlank public String name;
    @Email @NotBlank @Column(unique = true) public String email;
    @NotBlank public String department;
    public String jobRole;
    public String primarySkill;
    @Min(0) public Integer experienceYears;
    protected Employee() {}
}

@Entity
@Table(name = "skills")
class Skill {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @NotBlank @Column(unique = true) public String name;
    @NotBlank public String category;
    public String description;
    protected Skill() {}
}

@Entity
@Table(name = "employee_skills", uniqueConstraints = @UniqueConstraint(columnNames = {"employee_id", "skill_id"}))
class EmployeeSkill {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "employee_id")
    public Employee employee;
    @ManyToOne(optional = false) @JoinColumn(name = "skill_id")
    public Skill skill;
    @Min(1) @Max(10) public Integer rating;
    public String proficiencyLevel;
    protected EmployeeSkill() {}
}

@Entity
@Table(name = "assessments")
class Assessment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "employee_id")
    public Employee employee;
    @ManyToOne @JoinColumn(name = "skill_id")
    public Skill skill;
    @Min(0) @Max(100) public Integer score;
    public String assessor;
    public LocalDate assessedOn = LocalDate.now();
    public Boolean passed = false;
    protected Assessment() {}
}

@Entity
@Table(name = "certifications")
class Certification {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @ManyToOne(optional = false) @JoinColumn(name = "employee_id")
    public Employee employee;
    @NotBlank public String certificationName;
    public String issuer;
    public LocalDate issueDate;
    public LocalDate expiryDate;
    public String status = "ACTIVE";
    @Column(unique = true) public String certificateNumber;
    public Integer score;
    public Long assessmentId;
    protected Certification() {}
}


@Entity
@Table(name = "module_records")
class ModuleRecord {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;
    @Column(nullable = false, length = 100) public String moduleKey;
    @Column(nullable = false, length = 250) public String title;
    @Column(columnDefinition = "text") public String details;
    public java.time.LocalDateTime createdAt = java.time.LocalDateTime.now();
    protected ModuleRecord() {}
}
