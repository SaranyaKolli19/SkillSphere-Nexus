package com.skillsphere;

import org.springframework.http.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;
import jakarta.validation.Valid;
import java.util.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.time.LocalDate;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:4200", "http://localhost:4201"})
public class ApiController {
    private final EmployeeRepository employees;
    private final SkillRepository skills;
    private final EmployeeSkillRepository employeeSkills;
    private final AssessmentRepository assessments;
    private final CertificationRepository certifications;
    private final ModuleRecordRepository moduleRecords;
    private final ObjectMapper objectMapper;

    public ApiController(EmployeeRepository e, SkillRepository s, EmployeeSkillRepository es,
                         AssessmentRepository a, CertificationRepository c, ModuleRecordRepository mr, ObjectMapper mapper) {
        employees=e; skills=s; employeeSkills=es; assessments=a; certifications=c; moduleRecords=mr; objectMapper=mapper;
    }

    @GetMapping("/health")
    public Map<String,String> health() { return Map.of("status","UP","app","SkillSphere Nexus M1"); }

    @GetMapping("/employees") public List<Employee> allEmployees() { return employees.findAll(); }
    @GetMapping("/employees/{id}") public Employee employee(@PathVariable Long id) {
        return employees.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Employee not found"));
    }
    @PostMapping("/employees") public Employee createEmployee(@Valid @RequestBody Employee e) { e.id=null; return employees.save(e); }
    @PutMapping("/employees/{id}") public Employee updateEmployee(@PathVariable Long id,@Valid @RequestBody Employee e) {
        if (!employees.existsById(id)) throw new ResponseStatusException(HttpStatus.NOT_FOUND,"Employee not found");
        e.id=id; return employees.save(e);
    }
    @DeleteMapping("/employees/{id}") public void deleteEmployee(@PathVariable Long id) { employees.deleteById(id); }

    @GetMapping("/skills") public List<Skill> allSkills() { return skills.findAll(); }
    @PostMapping("/skills") public Skill createSkill(@Valid @RequestBody Skill s) { s.id=null; return skills.save(s); }
    @DeleteMapping("/skills/{id}") public void deleteSkill(@PathVariable Long id) { skills.deleteById(id); }

    @GetMapping("/employee-skills/employee/{employeeId}") public List<EmployeeSkill> skillsForEmployee(@PathVariable Long employeeId) {
        return employeeSkills.findByEmployeeId(employeeId);
    }
    @PostMapping("/employee-skills/{employeeId}/{skillId}")
    public EmployeeSkill addSkill(@PathVariable Long employeeId,@PathVariable Long skillId,
                                  @RequestParam(defaultValue="1") Integer rating,
                                  @RequestParam(defaultValue="Beginner") String proficiencyLevel) {
        Employee e=employees.findById(employeeId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Employee not found"));
        Skill s=skills.findById(skillId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Skill not found"));
        EmployeeSkill es=new EmployeeSkill(); es.employee=e; es.skill=s; es.rating=rating; es.proficiencyLevel=proficiencyLevel;
        return employeeSkills.save(es);
    }

    @GetMapping("/assessments") public List<Assessment> allAssessments() { return assessments.findAll(); }
    @PostMapping("/assessments") public Assessment createAssessment(@RequestBody Map<String,Object> body) {
        Long employeeId=Long.valueOf(body.get("employeeId").toString());
        Long skillId=body.get("skillId")==null?null:Long.valueOf(body.get("skillId").toString());
        Assessment a=new Assessment();
        a.employee=employees.findById(employeeId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Employee not found"));
        if(skillId!=null) a.skill=skills.findById(skillId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Skill not found"));
        a.score=Integer.valueOf(body.get("score").toString());
        if (a.score < 0 || a.score > 100) throw new ResponseStatusException(HttpStatus.BAD_REQUEST,"Score must be between 0 and 100");
        a.assessor=Objects.toString(body.getOrDefault("assessor","HR"));
        a.passed = a.score >= 70;
        Assessment saved = assessments.save(a);
        if (Boolean.TRUE.equals(saved.passed)) {
            Certification certificate = new Certification();
            certificate.employee = saved.employee;
            certificate.certificationName = (saved.skill == null ? "SkillSphere Competency" : saved.skill.name) + " Assessment Certificate";
            certificate.issuer = "SkillSphere Nexus";
            certificate.issueDate = LocalDate.now();
            certificate.status = "ACTIVE";
            certificate.score = saved.score;
            certificate.assessmentId = saved.id;
            certificate.certificateNumber = "SSN-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase(Locale.ROOT);
            certifications.save(certificate);
        }
        return saved;
    }

    @GetMapping("/certifications") public List<Certification> allCertifications() { return certifications.findAll(); }
    @PostMapping("/certifications") public Certification createCertification(@RequestBody Map<String,Object> body) {
        Certification c=new Certification();
        Long employeeId=Long.valueOf(body.get("employeeId").toString());
        c.employee=employees.findById(employeeId).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,"Employee not found"));
        c.certificationName=Objects.toString(body.get("certificationName"));
        c.issuer=Objects.toString(body.getOrDefault("issuer",""));
        if(body.get("issueDate")!=null) c.issueDate=java.time.LocalDate.parse(body.get("issueDate").toString());
        if(body.get("expiryDate")!=null) c.expiryDate=java.time.LocalDate.parse(body.get("expiryDate").toString());
        c.status=(c.expiryDate!=null && c.expiryDate.isBefore(java.time.LocalDate.now()))?"EXPIRED":"ACTIVE";
        return certifications.save(c);
    }


    @GetMapping("/module-records/{moduleKey}")
    public List<ModuleRecord> moduleRecords(@PathVariable String moduleKey) {
        return moduleRecords.findByModuleKeyOrderByCreatedAtDesc(moduleKey);
    }

    @PostMapping("/module-records/{moduleKey}")
    public ModuleRecord createModuleRecord(@PathVariable String moduleKey, @RequestBody Map<String,Object> body) {
        if (body == null || body.isEmpty()) throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "At least one field is required");
        ModuleRecord record = new ModuleRecord();
        record.moduleKey = moduleKey;
        Object title = body.get("courseTitle");
        if (title == null) title = body.get("jobTitle");
        if (title == null) title = body.get("initiativeName");
        if (title == null) title = body.get("frameworkName");
        if (title == null) title = body.get("reportName");
        if (title == null) title = body.get("careerGoal");
        if (title == null) title = body.get("employeeName");
        if (title == null) title = body.get("targetSkill");
        if (title == null) title = body.get("competency");
        if (title == null) title = body.get("strengths");
        if (title == null) title = body.get("title");
        record.title = String.valueOf(title == null ? moduleKey.replace('-', ' ') : title);
        try { record.details = objectMapper.writerWithDefaultPrettyPrinter().writeValueAsString(body); }
        catch (Exception ex) { throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Could not save submitted fields"); }
        return moduleRecords.save(record);
    }

    @DeleteMapping("/module-records/{moduleKey}/{id}")
    public ResponseEntity<Void> deleteModuleRecord(@PathVariable String moduleKey, @PathVariable Long id) {
        ModuleRecord record = moduleRecords.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Record not found"));
        if (!record.moduleKey.equals(moduleKey)) throw new ResponseStatusException(HttpStatus.NOT_FOUND, "Record not found in this module");
        moduleRecords.delete(record);
        return ResponseEntity.noContent().build();
    }
}
