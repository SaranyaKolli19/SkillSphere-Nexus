# SkillSphere Nexus - Integrated local build

## What is included
- Angular forms and saved-record views for Employee Management, Skill Management, Assessments, Certifications, Career Development, Training Administration, Competency Framework, Internal Job Opportunities, Learning Analytics, Workforce Development, and Enterprise Talent Management.
- Spring Boot APIs for employees, skills, assessments, certifications, and generic module records.
- A passing assessment score of 70/100 or more creates a certification record automatically.
- Default persistent H2 file database: `backend/data/skillsphere_m1`. It survives backend restarts and does not require the PostgreSQL password to run the app immediately.
- Optional PostgreSQL profile is included at `backend/src/main/resources/application-postgres.properties` for when PostgreSQL credentials are available.

## Run on Windows
1. Open PowerShell window 1:
   ```powershell
   cd "C:\Users\vasum\Downloads\SkillSphere-Nexus-M1\backend"
   .\mvnw.cmd spring-boot:run
   ```
2. Open PowerShell window 2:
   ```powershell
   cd "C:\Users\vasum\Downloads\SkillSphere-Nexus-M1\frontend"
   & "C:\Program Files\nodejs\npm.cmd" install
   & "C:\Program Files\nodejs\npm.cmd" start
   ```
3. Open `http://localhost:4200`.
4. Check backend at `http://localhost:8080/api/health`.

## PostgreSQL profile (after password is known/reset)
Set the environment variables in the same backend PowerShell window, then start with the PostgreSQL profile:
```powershell
$env:DB_USERNAME = "postgres"
$env:DB_PASSWORD = "YOUR_POSTGRES_PASSWORD"
$env:DB_URL = "jdbc:postgresql://localhost:5432/skillsphere_db"
.\mvnw.cmd spring-boot:run "-Dspring-boot.run.profiles=postgres"
```
Do not put a real password into source files or share it in chat. The PostgreSQL profile uses `ddl-auto=update`, which creates/updates tables but does not intentionally drop existing tables.

## Important
- The default H2 database is persistent local storage, not PostgreSQL. The app uses it so you can test the integrated website now while the PostgreSQL password issue is unresolved.
- Existing H2 memory-only records from the previous build will not be present in the new file database.
- The generic modules store submitted fields as JSON text in `module_records`; employee, skill, assessment and certification data use dedicated tables.
- Certificate creation currently uses a pass threshold of 70/100. Change that threshold in `ApiController.java` if your project specification requires a different value.
